To open this project, you need to open Unity hub and create new project.

Then go to Assets -> import Packages -> custom package then select the "Missile_Attack_Final_Project_HoloLens" package file.





